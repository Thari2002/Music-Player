/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music_player;

public class Node {
    
    String data;
    Node next;
    
    Node(String d) {
        data = d; next = null; 
    }

}


