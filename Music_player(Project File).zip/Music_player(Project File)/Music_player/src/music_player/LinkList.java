/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music_player;

public class LinkList {
    
    Node head;
    
    public void insert_At_End(String udata){
        
        Node nodeobj = new Node(udata);
        nodeobj.data = udata;
        nodeobj.next=null;
        
        if(head == null){
            head = nodeobj;            
        }else{
            Node temp = head;
            while (temp.next != null){
                temp=temp.next;                
            }
            temp.next = nodeobj;
            nodeobj.next= null;    
                        
        }  
    }
    
    /* Returns count of nodes in linked list */
    public int getCountRec(Node node){
        // Base case
        if (node == null)
            return 0; 
        // Count is this node plus rest of the list
        return 1 + getCountRec(node.next);
    }
 
    /* Wrapper over getCountRec() */
    public int getCount(){    
        return getCountRec(head);
    }
    
    
    public String next_song(int index){
        Node node = head;
        String dat = null;
        if(index==1){
            return node.data;
        }else{
            for(int i=0; i<index-1; i++) {
                node=node.next;
                dat =node.data;
            }
        }
        
        return dat;
    }
    
    public void delete_at_given_index(int index){
        
        if(index==0){
            head=head.next;
        }else{
            Node temp =head;
            Node temp1;
            
            for(int i=0; i<index-1; i++){
                temp=temp.next;
            }
            temp1=temp.next;
            temp.next=temp1.next;
        }
    }

    public void showlist(){
        
        Node node = head;
        
        while (node.next != null) {
            System.out.println("Node data: "+node.data+"    Node address: "+node.next);
            node=node.next; 
        }
        System.out.println("Node data: "+node.data+"    Node address: "+node.next);
        
    }
     
}
