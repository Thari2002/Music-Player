/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music_player;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;


public class Music_player extends JFrame{
    
    Music_player frame;
    int num;
    int num1,ps;
    int song_index =1;
    
    Music_player(){
        
        setLayout(null);

        LinkList obj = new LinkList();
        
            JLabel b6 = new JLabel();
            b6.setIcon(new ImageIcon(getClass().getResource("x.png")));
            b6.setBackground(new Color(0,0,0,0));
            b6.setBounds(250,5,30,30);
            add(b6);
            
            b6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            b6.setIcon(new ImageIcon(getClass().getResource("x-RED.png")));
            b6.setBackground(new Color(0, 0, 0,0));
            b6.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            b6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
            b6.setIcon(new ImageIcon(getClass().getResource("x.png")));
            b6.setBackground(new Color(0, 0, 0,0));
            }
            });
            b6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                
                ClaseWindow frame=new ClaseWindow();
                

            }
            });
            
            
             
            JLabel b7 = new JLabel();
            b7.setIcon(new ImageIcon(getClass().getResource("m1.png")));
            b7.setBackground(new Color(0,0,0,0));
            b7.setBounds(210,5,30,30);
            add(b7);
            b7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            b7.setIcon(new ImageIcon(getClass().getResource("m_B.png")));
            b7.setBackground(new Color(0, 0, 0,0));
            b7.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            b7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
            b7.setIcon(new ImageIcon(getClass().getResource("m1.png")));
            b7.setBackground(new Color(0, 0, 0,0));
            }
            });
            b7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

              setState(Music_player.ICONIFIED);

            }
            });
            
            
        JPanel p = new JPanel();
        p.setBounds(0,0,800,40);
        p.setBackground(new Color(46, 64, 83,250)); 
        add(p);
        
        JLabel cu = new JLabel("",SwingConstants.CENTER);
        cu.setBounds(50,460,200,35);
        cu.setForeground(Color.orange);
        add(cu);
        
        
        JLabel back = new JLabel();
        back.setIcon(new ImageIcon(getClass().getResource("back.png")));
        back.setBounds(82,180,16,19);
        add(back);
        
        JLabel play = new JLabel();
        play.setIcon(new ImageIcon(getClass().getResource("play.png")));
        play.setBounds(146,180,10,19);
        add(play);
        
        JLabel next = new JLabel();
        next.setIcon(new ImageIcon(getClass().getResource("next.png")));
        next.setBounds(202,180,16,19);
        add(next);
        
        
        JLabel lk = new JLabel();
        lk.setIcon(new ImageIcon(getClass().getResource("background.png")));
        lk.setBounds(62,170,175,40);
        add(lk);
        
        JTable table = new JTable();
        Object[] columns = {"No","Song Play List"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        Font col = new Font("Century (Body",Font.BOLD,15);
        setFont(col);
        table.setModel(model);
        //to change the backgraund color
        Color ivory = new Color(36, 44, 23,230);
        table.setOpaque(true);
        table.setFillsViewportHeight(true);
        table.setBackground(ivory);
        table.setForeground(Color.WHITE);
        Font font = new Font("Century",1,12);
        table.setFont(font);
        table.setRowHeight(25);
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(1).setPreferredWidth(240);
        table.setDefaultEditor(Object.class, null);
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(10, 260, 280, 200);
        table.setShowGrid(true);
        table.setBorder(null);
        add(pane);
        
            table.addMouseListener(new MouseListener() {
            @Override
            public void mouseReleased(MouseEvent e) {
            }
            @Override
            public void mousePressed(MouseEvent e) {
                int selectedCellValue = table.getSelectedRow()+1;
                song_index = selectedCellValue;
                System.out.println("Row index : "+selectedCellValue);
            }
            @Override
            public void mouseExited(MouseEvent e) {
            }
            @Override
            public void mouseEntered(MouseEvent e) {
            }
            @Override
            public void mouseClicked(MouseEvent e) {
            }
            });
        
            back.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                back.setToolTipText("Previous");
                back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            back.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            back.setIcon(new ImageIcon(getClass().getResource("back_c.png")));
            back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });            
            back.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
            back.setIcon(new ImageIcon(getClass().getResource("back.png")));
                if(song_index!=1){
                    song_index = song_index-1; 
                    cu.setText(obj.next_song(song_index));
                    table.setRowSelectionInterval(song_index-1, song_index-1);
                }
            }
            });
            
            ps = 1;
            
            play.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if(ps==1){
                    play.setToolTipText("Play");
                }else{
                    play.setToolTipText("Pause");
                } 
                play.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });

            play.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            play.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));      

                if(obj.getCount()==0){
                    play.setIcon(new ImageIcon(getClass().getResource("play_c.png")));
                    cu.setText("****First, Please add a song*** ");
                }else{

                    if(ps==1){
                        play.setIcon(new ImageIcon(getClass().getResource("play_c.png")));
                        play.setBounds(play.getX()-1, play.getY(), play.getWidth(), play.getHeight()); 
                        cu.setText("****Now playing "+obj.next_song(song_index)+"*** ");
                        table.setRowSelectionInterval(song_index-1, song_index-1);
                        cu.setForeground(Color.orange);
                    }else{
                        play.setIcon(new ImageIcon(getClass().getResource("stop_c.png")));
                        cu.setText("****Paused*** ");
                        cu.setForeground(Color.red);
                    }                           
                }                          
            }
            });
            play.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                
                if(obj.getCount()==0){
                    play.setIcon(new ImageIcon(getClass().getResource("play.png")));
                }else{
                    if(ps==1){
                        play.setIcon(new ImageIcon(getClass().getResource("stop.png")));
                        play.setBounds(play.getX()-1, play.getY(), play.getWidth()+2, play.getHeight());
                        ps=0;
                    }else{
                        play.setIcon(new ImageIcon(getClass().getResource("play.png")));
                        play.setBounds(146,180,10,19);
                        ps=1;
                    }
                }            
            }
            });

            next.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                next.setToolTipText("Next");
                next.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            next.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            next.setIcon(new ImageIcon(getClass().getResource("next_c.png")));
            next.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            next.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {

                if(obj.getCount()>song_index){
                    song_index = song_index+1;  
                    cu.setText(obj.next_song(song_index));
                    table.setRowSelectionInterval(song_index-1, song_index-1);
                }
                next.setIcon(new ImageIcon(getClass().getResource("next.png")));
               
            }
            });


        JLabel img = new JLabel();
        img.setIcon(new ImageIcon(getClass().getResource("sd.png")));
        img.setBackground(new Color(0,0,0,0));
        img.setBounds(0,30,300,170);
        add(img);
        
        JLabel hd = new JLabel();
        hd.setIcon(new ImageIcon(getClass().getResource("add.png")));
        hd.setBounds(10,225,62,18);
        add(hd);
        
        JLabel k = new JLabel();
        k.setIcon(new ImageIcon(getClass().getResource("delete.png")));
        k.setBounds(82,225,62,18);
        add(k);
        
        JLabel kd = new JLabel();
        kd.setIcon(new ImageIcon(getClass().getResource("update.png")));
        kd.setBounds(154,225,62,18);
        add(kd);
        
        JLabel kl = new JLabel();
        kl.setIcon(new ImageIcon(getClass().getResource("sort.png")));
        kl.setBounds(226,225,62,18);
        add(kl);
        
            hd.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hd.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            k.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                k.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            
            kd.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                kd.setToolTipText("Unavailable");
            }
            });
            kl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                kl.setToolTipText("Unavailable");
            }
            });

        
        Object[] row = new Object[5];        

        num1 = 1;
        int tot = num + num1;

        hd.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {

            FileNameExtensionFilter songFilter = new FileNameExtensionFilter("Music Files", "mp3");

            String path = System.getProperty("user.home");
            JFileChooser chooseMusic = new JFileChooser(path + "\\Music");

            chooseMusic.setFileFilter(songFilter);

            int result = chooseMusic.showDialog(frame,"Add Music");


            if (result == JFileChooser.APPROVE_OPTION)  {

                File selectedMusic = chooseMusic.getSelectedFile();

                Path p = Paths.get(selectedMusic.toString());
                String file = p.getFileName().toString();

                num = num + 1;          
                System.out.println("tot :" + num);

                obj.insert_At_End(file);
                obj.showlist();

                System.out.flush();  

                row[0] = num;
                row[1] = file;
                model.addRow(row);
                table.setRowSelectionInterval(song_index-1, song_index-1);

            }


        }   
        });
        
        k.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            
            if(obj.getCount()!=0){
                obj.delete_at_given_index(song_index-1);
                
                num=num-1;
                model.setRowCount(0);
                
                for(int i=1; i<=num; i++){
                    row[0] = i;
                    row[1] = obj.next_song(i);
                    model.addRow(row);
                    cu.setText("***Song No "+song_index+" is Deleted***");
                }
            }
            
            if(obj.getCount()!=0){
                obj.showlist();
            }else{
                System.out.println("----------------------------");
                System.out.println("Linked List is empty");
                System.out.println("----------------------------");
            }
        }
        });

        setUndecorated(true);
        setSize(300,500);
        setLayout(new BorderLayout());
        setBackground(new Color(46, 64, 83,250));           
        setLocationRelativeTo(null);                
        setLayout(new BorderLayout());
        getRootPane().setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
        setVisible(true);    
    }

    public static void main(String[] args) {
        
        Music_player frame = new Music_player ();
    }
    
}
