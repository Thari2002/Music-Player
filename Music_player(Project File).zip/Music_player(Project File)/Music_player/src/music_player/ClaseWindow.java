/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music_player;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class ClaseWindow  extends JFrame {
 
        ClaseWindow (){
             
             setLayout(null);
             
            JLabel b42 = new JLabel("Close Program");
            Font q23 = new Font("Century",Font.BOLD,15); 
            b42.setFont(q23);
            b42.setForeground(Color.WHITE);
            b42.setBackground(new Color(0,0,0,0));
            b42.setBounds(45,165,200,70);
            add(b42);
            
            JLabel b43 = new JLabel("Do you want to exit ?");
            Font q233 = new Font("Century",Font.BOLD,12); 
            b43.setFont(q233);
            b43.setForeground(Color.cyan);
            b43.setBackground(new Color(0,0,0,0));
            b43.setBounds(45,205,250,50);
            add(b43);
             
//            JPanel nd = new JPanel();
//            nd.setBackground(Color.RED);
//            nd.setBounds(45,320,100,30);
//            add(nd);
            
            JLabel b41 = new JLabel();
            b41.setIcon(new ImageIcon(getClass().getResource("no.png")));
            b41.setBackground(new Color(0,0,0,0));
            b41.setBounds(40,260,100,36);
            add(b41);
            
            b41.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            b41.setIcon(new ImageIcon(getClass().getResource("no_d.png")));
            b41.setBackground(new Color(0, 0, 0,0));
            b41.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            b41.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
            b41.setIcon(new ImageIcon(getClass().getResource("no.png")));
            b41.setBackground(new Color(0, 0, 0,0));
            }
            });
            
            b41.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                dispose();
                
            }
                
            });

            
            
            
            
            JLabel b4 = new JLabel();
            b4.setIcon(new ImageIcon(getClass().getResource("yes.png")));
            b4.setBackground(new Color(0,0,0,0));
            b4.setBounds(155,260,100,36);
            add(b4);
            
            b4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            b4.setIcon(new ImageIcon(getClass().getResource("yes_d.png")));
            b4.setBackground(new Color(0, 0, 0,0));
            b4.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            });
            b4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
            b4.setIcon(new ImageIcon(getClass().getResource("yes.png")));
            b4.setBackground(new Color(0, 0, 0,0));
            }
            });
                        
            b4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
     
                System.exit(0);
    
                
            }
                
            });
            
            
            
            JPanel q1 = new JPanel();       
            q1.setBounds(25,169,250,150);
            q1.setBackground(new Color(93, 109, 126));
            add(q1);
            
            JPanel q2 = new JPanel();       
            q2.setBounds(24,168,252,152);
            q2.setBackground(Color.cyan);
            add(q2);
            
            
            
            
            
           
            
            
            
            setUndecorated(true);
            setSize(300,500);
            setLayout(new BorderLayout());
            setBackground(new Color(46, 64, 83,200));           
            setLocationRelativeTo(null);                
            setLayout(new BorderLayout());
            getRootPane().setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            setVisible(true);        

         }
        
    

    public static void main(String[] args) {
        
        ClaseWindow  frame = new ClaseWindow ();
    }

}



